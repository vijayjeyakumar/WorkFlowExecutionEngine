<template>
  <div id="app">
    <header>
      <h1>WorkFlow Execution Tool</h1>
    </header>

    <main>
      <h2>Select the required workflows you wish to run</h2>

      <!-- Dropdown Box Added Here -->
      <div class="workflow-header">
        <div class="workflow-dropdown">
          <label>
            Select Execution Environment:
            <select v-model="executionEnviroment">
              <option value="dev">GCPPMM</option>
            </select>
          </label>

          <label>
            Select Execution Tenant:
            <select v-model="executionTenant">
              <option value="dev">SeleniumDevDPC2</option>
            </select>
          </label>
        </div>
      </div>

      <form @submit.prevent="submitForm">
        <div class="workflow-options">
          <label class="checkbox">
            <input type="checkbox" v-model="generateSegmentation" />
            Generate Product Level Segmentation
          </label>
          <div v-if="generateSegmentation" class="segmentation-input">
            <label>
              Select ForecastGenerationTimeBucketValue :
              <select v-model="generateSegmentationData">
                <option value="Week">Week</option>
                <option value="Month">Month</option>
                <option value="Quarter">Planning Month</option>
              </select>
            </label>
          </div>

          <label class="checkbox">
            <input type="checkbox" v-model="outlierCorrectionInput" />
            Run Outlier Correction
          </label>
          <label class="checkbox">
            <input type="checkbox" v-model="statForecastInput" />
            Run Stat Forecast
          </label>
        </div>

        <button type="submit" class="submit-button">Run WorkFlows</button>
      </form>

      <div v-if="submitted" class="submission-message">
        <p>You have submitted the following workflows:</p>
        <ul>
          <li v-if="generateSegmentation">Generate Product Level Segmentation</li>
          <li v-if="outlierCorrectionInput">Run Outlier Correction</li>
          <li v-if="statForecastInput">Run Stat Forecast</li>
        </ul>
      </div>

      <!-- Display the Job URL below the submit button -->
      <div v-if="jobUrl" class="job-url">
        <p>
          Job URL: <a :href="jobUrl" target="_blank">{{ jobUrl }}</a>
        </p>
      </div>
    </main>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  data() {
    return {
      executionTenant: 'SeleniumDevDPC2', // Default value
      executionEnviroment: 'GCPPMM', // Default value
      generateSegmentation: false,
      generateSegmentationData: '', // Add this
      outlierCorrectionInput: false,
      statForecastInput: false,
      submitted: false,
      jobUrl: '', // Add this
      versionName: 'currentWorkingView', // Default value
      ForecastGenerationTimeBucketValue: 'Week' // Default value
    }
  },
  methods: {
    submitForm() {
      console.log('Form is being submitted')
      console.log('generateSegmentationData:', this.generateSegmentationData) // Add this line

      const payload = {
        generateSegmentation: this.generateSegmentation ? 'Yes' : 'No',
        generateSegmentationData: this.generateSegmentation ? this.generateSegmentationData : '', // Ensure value is set
        outlierCorrectionInput: this.outlierCorrectionInput ? 'Yes' : 'No',
        statForecastInput: this.statForecastInput ? 'Yes' : 'No'
      }
      console.log('The payload is : ', payload)
      axios
        .post('http://127.0.0.1:5000/triggerJobRun', payload, {
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .then((response) => {
          console.log('Form submitted successfully:', response.data)
          this.jobUrl = response.data['Job url']
          this.submitted = true
        })
        .catch((error) => {
          console.error('Error submitting the form:', error)
        })
    }
  }
}
</script>

<style scoped>
#app {
  font-family: Arial, Helvetica, sans-serif;
  color: #333;
  padding: 20px;
  height: 100vh; /* Full viewport height */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, hsl(203, 87%, 45%), #e2ebf0); /* Softer gradient background */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
  width: 100vw; /* Full viewport width */
}

header h1 {
  font-size: 2.5em;
  text-align: center;
  margin-bottom: 100px;
  color: #444;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

main {
  width: 100%;
  max-width: 1200px; /* Maximum width for readability */
  background: rgba(255, 255, 255, 0.95);
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  text-align: center; /* Center align the text */
}

h2 {
  font-size: 1.8em;
  margin-bottom: 20px;
  color: #333;
}

.workflow-options {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 30px;
}

.workflow-header {
  display: flex;
  flex-direction: column;
  gap: 100px;
  margin-bottom: 50px;
  background-color: aliceblue;
}

.workflow-dropdown {
  display: flex;
  gap: 100px;
  background-color: aliceblue;
}

.checkbox {
  font-size: 1.2em;
  color: #444;
  display: flex;
  align-items: center;
  background: #f5f5f5;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
}

.checkbox input {
  margin-right: 10px;
  accent-color: #6394f8;
}

.submit-button {
  background-color: #af80ff;
  color: rgb(255, 255, 255);
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.3em;
  transition: background-color 0.3s ease;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

.submit-button:hover {
  background-color: #ff8066;
}

.submission-message {
  margin-top: 30px;
  font-size: 1.2em;
  color: #333;
}

.submission-message ul {
  margin-top: 15px;
  list-style-type: disc;
  padding-left: 25px;
}

.submission-message li {
  margin-bottom: 8px;
}
</style>
