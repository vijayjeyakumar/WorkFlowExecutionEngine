import threading
import flask
import requests
import json
from flask import Flask, render_template, request, jsonify, json
import subprocess
import pymysql
import pymysql.cursors
from waitress import serve

# Creates Flask with  our project name as argument
app = Flask(__name__)

from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all origins

# Decorator wraps our function given in it and calls it when the web server receives request that matches the request
@app.route('/')
# To enable cross origin
# @cross_origin()
def testFunction():
    return "Welcome To REE Connector", 200


# Trigger Job
@app.route('/triggerJobRun', methods=['POST'])
# @cross_origin()
def triggerJobRun():
    if request.method == 'OPTIONS':
        # Handle preflight request
        response = jsonify({'message': 'CORS preflight response'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Methods', 'POST, OPTIONS')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        return response
    print("generateSegmentationData provided by the user is")
    # Fetching Json Request From FrontEnd
    json_data = flask.request.json
    generateSegmentationInput = json_data["generateSegmentation"]
    generateSegmentationData = json_data["generateSegmentationData"]
    outlierCorrectionInput = json_data["outlierCorrectionInput"]
    statForecastInput = json_data["statForecastInput"]

    print(json_data)
    print("generateSegmentationData provided by the user is", generateSegmentationData)
    pathOfGenerateSegmentationDataFile = r"C:\Users\vijay.jeyakumar\PycharmProjects\REEConnectAPI\O9_PMM_QASelenium\src\main\java\com\o9\test\DP\IDBPreRequisite\GenerateSegmentation\data.properties"

    # Read the file content
    with open(pathOfGenerateSegmentationDataFile, 'r') as file:
        lines = file.readlines()

    # Replace the value after "input=" with "Month"
    with open(pathOfGenerateSegmentationDataFile, 'w') as file:
        for line in lines:
            if line.startswith('input='):
                line = 'input=' + generateSegmentationData + '\n'
            file.write(line)
    print("Data Replacement complete!")

    testJobFinalURL = triggerReeJob()
   # testJobFinalURL = 201
    threading.Thread(target=uploadLatestScriptsToGit).start()
    return jsonify({'Response': "Job Submitted Successfully", 'Job url': testJobFinalURL}), 200


push_script = """
$gitUsername = "mayank.dhawariya"
$gitToken = "42haek7pzsk223dthh7ywjaohxmkx6nfxg66uynhwgxgy4q5sfkq"

$gitCloneUrl = "https://${gitUsername}:${gitToken}@o9git.visualstudio.com/RefDev/_git/O9_PMM_QASelenium"

Write-Host Cloning git
git clone --branch VijayJeyakumar_Hackathon $gitCloneUrl
cd O9_PMM_QASelenium

Write-Host 'Git Branch & Status'
git branch
git status

Write-Host 'Adding files to staging area'
git add .
git status


Write-Host 'Committing files to local repo'
git commit -m "fixing the trailing spaces by cleanup utility"
git status


Write-Host 'Pushing changes to main repo'
git push origin main
git status
"""


def uploadLatestScriptsToGit():
    print("\nCommencing Upload to Git!\n")
    # time.sleep(2)
    result = subprocess.run(['powershell', '-Command', push_script], capture_output=True, text=True)
    if result.returncode != 0:
        print("Error occurred while pushing changes:")
        print(result.stderr)
        raise RuntimeError("Failed to push changes to repository")
    else:
        print("Changes pushed to repo successfully.\nOutput:")
        print(result.stdout)

    print("\nFile Uploaded to Git!\n")


def triggerReeJob():
    testJobBaseURL = "http://10.131.38.21:3000/ree/projects/1/testJobDetails"
    reeURL = "http://10.131.38.21:3000/ree/projects/1/run_job_schedule"
    print("Triggering REE Job")
    payload = json.dumps({
        "template_details": [
            {
                "template_id": 90,
                "config_tag": "NA"
            }
        ]
    })
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", reeURL, headers=headers, data=payload)
    print(response.text)
    # return response

    if (response.status_code != 200 and response.status_code != 201):
        err = f"Failed to trigger the job for template ID:  90"
        raise Exception(err)

    jobID = response.json()['job_ids'][0]
    print(f"jobID: {jobID}")

    testJobFinalURL = testJobBaseURL + f"/{jobID}"
    print(f"testJobFinalURL: {testJobFinalURL}")

    return testJobFinalURL


 # Main Function that specifies port,host etc
if __name__ == '__main__':
     app.run(host=None, port=5000, debug=True)
# Required to server from server
     serve(app, host='localhost', port=5000, threads=1)  # WAITRESS!